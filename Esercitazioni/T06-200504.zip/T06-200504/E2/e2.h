#ifndef __E2__
#define __E2__

int count_occ_seq(const char* v, int n, char x);
int count_occ(const char* v, int n, char x);

#endif
