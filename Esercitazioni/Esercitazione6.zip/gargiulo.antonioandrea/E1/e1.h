#ifndef __E3__
#define __E3__

void matmul_seq(const short** a, const short** b, short** c, int n);
void matmul(const short** a, const short** b, short** c, int n);

#endif
