object E4 {
    def isAnagramOf(a:String, b:String) = ??? // completa metodo
}
