sealed abstract class Tree {
    // Inserisci la soluzione qui...
}

// albero non vuoto
case class T(l:Tree, e:Int, r:Tree) extends Tree 

// albero vuoto
case class E() extends Tree
