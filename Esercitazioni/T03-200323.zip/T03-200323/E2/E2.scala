object E2 {
    def getModel(n:Int):List[Shape] = ??? // scrivi corpo della funzione
}
