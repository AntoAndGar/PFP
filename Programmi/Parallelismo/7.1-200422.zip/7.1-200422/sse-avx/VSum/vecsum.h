#ifndef VECSUM
#define VECSUM

void vecsum(int* A, int* B, int* C, int n);

#endif
