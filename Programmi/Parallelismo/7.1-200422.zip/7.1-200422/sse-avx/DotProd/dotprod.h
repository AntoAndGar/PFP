#ifndef __DOTPROD__
#define __DOTPROD__

int dotprod(int* A, int* B, int n);

#endif
