#include "cdiff.h"

int cdiff(const char* x, const char* y, int n) {
	// scrivere la soluzione vettorizzata qui...
	return 0;
}
