object C2 {
    def countSpaces(s:String) = s.filter(_==' ').size
}
