#ifndef __SUM__
#define __SUM__

int sum(int* v, int n);

#endif
