#ifndef __SUMEVEN__
#define __SUMEVEN__

int sumeven(const int* v, int n);
int sumeven_sse(const int* v, int n);

#endif
