#include "sumeven.h"

int sumeven_sse(const int* v, int n) {
    // scrivere la soluzione qui...
    return -1;
}
