import scala.language.implicitConversions

case class MyList[T](l:List[T]) {
    def project(mask:List[Boolean]):List[T] = {
        val m = l zip mask
        m.filter(t => t._2).map(t=>t._1)
    }
}

object MyList {
    implicit def List2MyList[T](l:List[T]) = MyList(l)
}
