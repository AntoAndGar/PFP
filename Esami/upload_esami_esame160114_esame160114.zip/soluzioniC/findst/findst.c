// =====================================================================
//  findst.c
// =====================================================================

//  Author:         (c) 2016 Camil Demetrescu
//  License:        See the end of this file for license information
//  Created:        Jan 13, 2016

//  Last changed:   $Date: 2016/01/13 --:--:-- $
//  Changed by:     $Author: demetres $
//  Revision:       $Revision: 1.00 $


#include "findst.h"
#include <pthread.h>
#include <assert.h>
#include <string.h>

// typedef
typedef struct {
    const char* pattern;
    const char* text;
    char* out;
    int n, p;
    int from, to;
} data_t;


// ---------------------------------------------------------------------
// _pthread_func
// ---------------------------------------------------------------------
void* _pthread_func(void* param) {

    data_t* d = (data_t*)param;
    int i, j;

    for (i=d->from; i<d->to; i++) {
        for (j=0; j<d->p; j++)
            if (d->text[i+j] != d->pattern[j]) break;
        d->out[i] = j==d->p;
    }

    return NULL;
}


// ---------------------------------------------------------------------
// findst
// ---------------------------------------------------------------------
void findst(const char* pattern, const char* text, char* out, int n) {

    pthread_t t1, t2, t3, t4;
    int i, res1, res2, res3, res4;

    int p = strlen(pattern);
    int m = n - p + 1;

    data_t dp1 = { pattern, text, out, n, p, 0,     m/4   };
    data_t dp2 = { pattern, text, out, n, p, m/4,   m/2   };
    data_t dp3 = { pattern, text, out, n, p, m/2,   3*m/4 };
    data_t dp4 = { pattern, text, out, n, p, 3*m/4, m     };

    res1 = pthread_create(&t1, NULL, _pthread_func, (void*)&dp1);
    res2 = pthread_create(&t2, NULL, _pthread_func, (void*)&dp2);
    res3 = pthread_create(&t3, NULL, _pthread_func, (void*)&dp3);
    res4 = pthread_create(&t4, NULL, _pthread_func, (void*)&dp4);

    assert(res1 == 0);
    assert(res2 == 0);
    assert(res3 == 0);
    assert(res4 == 0);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL); 
    pthread_join(t3, NULL);
    pthread_join(t4, NULL); 

    for (i=m; i<n; i++) out[i] = 0;
}


// Copyright (C) 2016 Camil Demetrescu

// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.

// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
// USA
