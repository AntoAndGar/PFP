object Point {
    case class PointList(l:List[Point]) {
        def +++(t:List[Point]) = l ::: t
    }
    implicit def list2PointList(l:List[Point]) = PointList(l)
}

case class Circle(x:Float, y:Float, r:Float) {
    def contains(p:Point) = r*r >= (p.x-x)*(p.x-x) + (p.y-y)*(p.y-y)
    def >?(l:List[Point]) = l forall(this.contains(_))
    def >>(l:List[Point]) = l filter(this.contains(_))
}

case class Point(x:Float, y:Float) {
    override def toString = "("+x+","+y+")"
}
