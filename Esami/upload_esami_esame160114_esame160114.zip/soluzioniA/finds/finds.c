// =====================================================================
//  finds.c
// =====================================================================

//  Author:         (c) 2016 Camil Demetrescu
//  License:        See the end of this file for license information
//  Created:        January 13, 2016

//  Last changed:   $Date: 2016/01/09 15:13:07 $
//  Changed by:     $Author: demetres $
//  Revision:       $Revision: 1.00 $


#include "finds.h"
#include <string.h>

#define LOCAL_SIZE  1024
#define KERNEL_NAME "finds"


// ---------------------------------------------------------------------
// finds
// ---------------------------------------------------------------------
// data-parallel GPU version

void finds(const char* pattern, const char* text, char* out, int n,  
           clut_device* dev, double* t) {

    int       err;      // error code
    cl_kernel kernel;   // execution kernel
    cl_mem    dtext;    // input text on device
    cl_mem    dpattern; // input pattern on device
    cl_mem    dout;     // output array on device
    cl_event  evt;      // performance measurement event
    
    int p = strlen(pattern);
    
    // create the compute kernel
    kernel = clCreateKernel(dev->program, KERNEL_NAME, &err);
    clut_check_err(err, "failed to create kernel");
    
    // allocate input text on device as a copy of input text on host
    dtext = clCreateBuffer(dev->context, 
                         CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, 
                         n, (void*)text, NULL);
    if (!dtext) clut_panic("failed to allocate input matrix on device memory");
    
    // allocate input pattern on device as a copy of input pattern on host
    dpattern = clCreateBuffer(dev->context, 
                         CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, 
                         p, (void*)pattern, NULL);

    if (!dpattern) clut_panic("failed to allocate input pattern on device memory");
       // allocate output array on device
    dout = clCreateBuffer(dev->context, 
                          CL_MEM_WRITE_ONLY, 
                          n, NULL, NULL);
    if (!dout) clut_panic("failed to allocate output array on device memory");
    
    // set the arguments to our compute kernel
    err  = clSetKernelArg(kernel, 0, sizeof(cl_mem), &dtext);
    err |= clSetKernelArg(kernel, 1, sizeof(cl_mem), &dpattern);
    err |= clSetKernelArg(kernel, 2, sizeof(cl_mem), &dout);
    err |= clSetKernelArg(kernel, 3, sizeof(int), &p);
    err |= clSetKernelArg(kernel, 4, sizeof(int), &n);
    clut_check_err(err, "failed to set kernel arguments");

    // execute the kernel over the range of our 1D input data set
    size_t local_dim[]  = { LOCAL_SIZE };
    size_t global_dim[] = { n };
    global_dim[0] = ((global_dim[0]+LOCAL_SIZE-1)/LOCAL_SIZE)*LOCAL_SIZE; // round up
    
    err = clEnqueueNDRangeKernel(dev->queue, kernel, 1, 
                                 NULL, global_dim, local_dim, 0, NULL, &evt);
    clut_check_err(err, "failed to execute kernel");
    
    // copy result from device to host
    err = clEnqueueReadBuffer(dev->queue, dout, CL_TRUE, 0, 
                              n, out, 0, NULL, NULL);
    clut_check_err(err, "failed to read output result");

    // return kernel execution time
    *t = clut_get_duration(evt);
    
    // cleanup
    clReleaseMemObject(dtext);
    clReleaseMemObject(dpattern);
    clReleaseMemObject(dout);
    clReleaseKernel(kernel);
}


// Copyright (C) 2016 Camil Demetrescu

// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.

// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
// USA
