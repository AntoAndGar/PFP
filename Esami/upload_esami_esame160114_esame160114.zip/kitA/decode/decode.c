#include "decode.h"

#include <string.h>

void decode(const char* key, int m, char* str) {
	// da completare
}
