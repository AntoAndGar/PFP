#include "minmax.h"

void minmax_sse(const unsigned char* v, int n, unsigned char* pmin, unsigned char* pmax){
    // da completare...
}

