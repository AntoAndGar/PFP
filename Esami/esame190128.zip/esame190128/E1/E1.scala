// completare questo file...

sealed abstract class Tree[T]
case class E[T]() extends Tree[T]
case class L[T](e:T) extends Tree[T]
case class N[T](l:Tree[T], e:T, r:Tree[T]) extends Tree[T]

