object B2 {
    def maxSubSeq[T](l:List[T], p:T => Boolean):List[T] = {
        l
    }
}
