object B3 {
    def test[T](l1:List[T], l2:List[T]):Boolean = {
        true
    }
}
