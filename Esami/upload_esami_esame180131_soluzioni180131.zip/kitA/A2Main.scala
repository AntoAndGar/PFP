import A2._

object A2Main extends App {
    var i = 0
    mywhile(i<5, "i="+i) {
        i+=1
    }
}
